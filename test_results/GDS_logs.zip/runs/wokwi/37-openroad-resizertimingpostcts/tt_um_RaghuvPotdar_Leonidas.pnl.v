module tt_um_RaghuvPotdar_Leonidas (clk,
    ena,
    rst_n,
    VPWR,
    VGND,
    ui_in,
    uio_in,
    uio_oe,
    uio_out,
    uo_out);
 input clk;
 input ena;
 input rst_n;
 inout VPWR;
 inout VGND;
 input [7:0] ui_in;
 input [7:0] uio_in;
 output [7:0] uio_oe;
 output [7:0] uio_out;
 output [7:0] uo_out;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire net39;
 wire net40;
 wire net41;
 wire net42;
 wire net43;
 wire net44;
 wire net45;
 wire net46;
 wire net47;
 wire net48;
 wire net49;
 wire net50;
 wire net51;
 wire net52;
 wire net53;
 wire net54;
 wire net55;
 wire net56;
 wire clknet_0_clk;
 wire busy;
 wire net1;
 wire tx;
 wire \uart.bit_idx[0] ;
 wire \uart.bit_idx[1] ;
 wire \uart.bit_idx[2] ;
 wire \uart.shifter[0] ;
 wire \uart.shifter[1] ;
 wire \uart.shifter[2] ;
 wire \uart.shifter[3] ;
 wire \uart.shifter[4] ;
 wire \uart.shifter[5] ;
 wire \uart.shifter[6] ;
 wire \uart.shifter[7] ;
 wire \uart.state[0] ;
 wire \uart.state[1] ;
 wire \uart.stop_done ;
 wire \uart.timer[0] ;
 wire \uart.timer[1] ;
 wire \uart.timer[2] ;
 wire \uart.timer[3] ;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire net35;
 wire net36;
 wire net37;
 wire net38;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net;
 wire clknet_2_0__leaf_clk;
 wire clknet_2_1__leaf_clk;
 wire clknet_2_2__leaf_clk;
 wire clknet_2_3__leaf_clk;
 wire net57;
 wire net58;
 wire net59;
 wire net60;
 wire net61;
 wire net62;
 wire net63;
 wire net64;
 wire net65;
 wire net66;
 wire net67;
 wire net68;
 wire net69;
 wire net70;
 wire net71;
 wire net72;
 wire net73;
 wire net74;
 wire net75;
 wire net76;
 wire net77;
 wire net78;
 wire net79;
 wire net80;
 wire net81;
 wire net82;
 wire net83;
 wire net84;

 sg13g2_inv_1 _094_ (.VDD(VPWR),
    .Y(_034_),
    .A(net75),
    .VSS(VGND));
 sg13g2_inv_1 _095_ (.VDD(VPWR),
    .Y(_035_),
    .A(net84),
    .VSS(VGND));
 sg13g2_inv_1 _096_ (.VDD(VPWR),
    .Y(_036_),
    .A(net72),
    .VSS(VGND));
 sg13g2_inv_1 _097_ (.VDD(VPWR),
    .Y(_037_),
    .A(net77),
    .VSS(VGND));
 sg13g2_inv_1 _098_ (.VDD(VPWR),
    .Y(_038_),
    .A(net57),
    .VSS(VGND));
 sg13g2_inv_1 _099_ (.VDD(VPWR),
    .Y(_039_),
    .A(net59),
    .VSS(VGND));
 sg13g2_inv_1 _100_ (.VDD(VPWR),
    .Y(_040_),
    .A(net64),
    .VSS(VGND));
 sg13g2_inv_1 _101_ (.VDD(VPWR),
    .Y(_041_),
    .A(net60),
    .VSS(VGND));
 sg13g2_inv_1 _102_ (.VDD(VPWR),
    .Y(_042_),
    .A(net62),
    .VSS(VGND));
 sg13g2_inv_1 _103_ (.VDD(VPWR),
    .Y(_043_),
    .A(net63),
    .VSS(VGND));
 sg13g2_inv_1 _104_ (.VDD(VPWR),
    .Y(_044_),
    .A(net74),
    .VSS(VGND));
 sg13g2_inv_1 _105_ (.VDD(VPWR),
    .Y(_045_),
    .A(net15),
    .VSS(VGND));
 sg13g2_nor2_1 _106_ (.A(\uart.state[1] ),
    .B(net14),
    .Y(_046_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_or2_1 _107_ (.VSS(VGND),
    .VDD(VPWR),
    .X(_047_),
    .B(net14),
    .A(net82));
 sg13g2_nand2b_1 _108_ (.Y(busy),
    .B(_046_),
    .A_N(\uart.stop_done ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand2_1 _109_ (.Y(_048_),
    .A(net10),
    .B(_046_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor2b_1 _110_ (.A(net14),
    .B_N(\uart.state[1] ),
    .Y(_049_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand2b_1 _111_ (.Y(_050_),
    .B(\uart.state[1] ),
    .A_N(net14),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand2_1 _112_ (.Y(_051_),
    .A(net69),
    .B(\uart.timer[0] ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and4_1 _113_ (.A(\uart.timer[3] ),
    .B(\uart.timer[2] ),
    .C(net69),
    .D(\uart.timer[0] ),
    .X(_052_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a22oi_1 _114_ (.Y(_053_),
    .B1(_049_),
    .B2(_052_),
    .A2(_046_),
    .A1(net10),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_inv_1 _115_ (.VDD(VPWR),
    .Y(_054_),
    .A(net11),
    .VSS(VGND));
 sg13g2_mux2_1 _116_ (.A0(net63),
    .A1(net2),
    .S(_050_),
    .X(_055_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _117_ (.B1(net15),
    .VDD(VPWR),
    .Y(_056_),
    .VSS(VGND),
    .A1(net12),
    .A2(_055_));
 sg13g2_a21oi_1 _118_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_044_),
    .A2(net12),
    .Y(_000_),
    .B1(_056_));
 sg13g2_mux2_1 _119_ (.A0(net62),
    .A1(net3),
    .S(_050_),
    .X(_057_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _120_ (.B1(net16),
    .VDD(VPWR),
    .Y(_058_),
    .VSS(VGND),
    .A1(net12),
    .A2(_057_));
 sg13g2_a21oi_1 _121_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_043_),
    .A2(net12),
    .Y(_001_),
    .B1(_058_));
 sg13g2_mux2_1 _122_ (.A0(net60),
    .A1(net4),
    .S(_050_),
    .X(_059_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _123_ (.B1(net16),
    .VDD(VPWR),
    .Y(_060_),
    .VSS(VGND),
    .A1(net12),
    .A2(_059_));
 sg13g2_a21oi_1 _124_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_042_),
    .A2(net12),
    .Y(_002_),
    .B1(_060_));
 sg13g2_mux2_1 _125_ (.A0(\uart.shifter[4] ),
    .A1(net5),
    .S(_050_),
    .X(_061_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _126_ (.B1(net16),
    .VDD(VPWR),
    .Y(_062_),
    .VSS(VGND),
    .A1(net13),
    .A2(_061_));
 sg13g2_a21oi_1 _127_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_041_),
    .A2(net13),
    .Y(_003_),
    .B1(_062_));
 sg13g2_mux2_1 _128_ (.A0(net59),
    .A1(net6),
    .S(_050_),
    .X(_063_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _129_ (.B1(net16),
    .VDD(VPWR),
    .Y(_064_),
    .VSS(VGND),
    .A1(net12),
    .A2(_063_));
 sg13g2_a21oi_1 _130_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_040_),
    .A2(net12),
    .Y(_004_),
    .B1(_064_));
 sg13g2_mux2_1 _131_ (.A0(net57),
    .A1(net7),
    .S(_050_),
    .X(_065_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _132_ (.B1(net16),
    .VDD(VPWR),
    .Y(_066_),
    .VSS(VGND),
    .A1(net11),
    .A2(_065_));
 sg13g2_a21oi_1 _133_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_039_),
    .A2(net11),
    .Y(_005_),
    .B1(_066_));
 sg13g2_mux2_1 _134_ (.A0(\uart.shifter[7] ),
    .A1(net8),
    .S(_050_),
    .X(_067_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _135_ (.B1(net15),
    .VDD(VPWR),
    .Y(_068_),
    .VSS(VGND),
    .A1(net11),
    .A2(_067_));
 sg13g2_a21oi_1 _136_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_038_),
    .A2(net11),
    .Y(_006_),
    .B1(_068_));
 sg13g2_nand2_1 _137_ (.Y(_069_),
    .A(net67),
    .B(net11),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand3_1 _138_ (.B(net9),
    .C(_046_),
    .A(net10),
    .Y(_070_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _139_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_069_),
    .A2(_070_),
    .Y(_007_),
    .B1(_045_));
 sg13g2_o21ai_1 _140_ (.B1(net82),
    .VDD(VPWR),
    .Y(_071_),
    .VSS(VGND),
    .A1(net14),
    .A2(net74));
 sg13g2_nand3_1 _141_ (.B(_047_),
    .C(_071_),
    .A(net15),
    .Y(_008_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and2_1 _142_ (.A(net84),
    .B(net72),
    .X(_072_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21o_1 _143_ (.A2(_072_),
    .A1(net75),
    .B1(_050_),
    .X(_073_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor2_1 _144_ (.A(_046_),
    .B(_051_),
    .Y(_074_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor3_1 _145_ (.A(_037_),
    .B(_046_),
    .C(_051_),
    .Y(_019_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_mux2_1 _146_ (.A0(net10),
    .A1(_052_),
    .S(_047_),
    .X(_020_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and3_1 _147_ (.X(_021_),
    .A(net82),
    .B(net14),
    .C(_020_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and2_1 _148_ (.A(net15),
    .B(_021_),
    .X(_009_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _149_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_073_),
    .A2(_020_),
    .Y(_022_),
    .B1(net65));
 sg13g2_a21oi_1 _150_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(net14),
    .A2(_020_),
    .Y(_023_),
    .B1(_045_));
 sg13g2_nor2b_1 _151_ (.A(net66),
    .B_N(_023_),
    .Y(_010_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _152_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(net14),
    .A2(_020_),
    .Y(_024_),
    .B1(net82));
 sg13g2_nor3_1 _153_ (.A(_045_),
    .B(_021_),
    .C(_024_),
    .Y(_011_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand2_1 _154_ (.Y(_025_),
    .A(net15),
    .B(_048_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_xnor2_1 _155_ (.Y(_026_),
    .A(net83),
    .B(_047_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor2_1 _156_ (.A(_025_),
    .B(_026_),
    .Y(_012_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _157_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(\uart.timer[0] ),
    .A2(_047_),
    .Y(_027_),
    .B1(net69));
 sg13g2_nor3_1 _158_ (.A(_074_),
    .B(_025_),
    .C(net70),
    .Y(_013_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor2_1 _159_ (.A(net77),
    .B(_074_),
    .Y(_028_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor3_1 _160_ (.A(_019_),
    .B(_025_),
    .C(net78),
    .Y(_014_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _161_ (.B1(net15),
    .VDD(VPWR),
    .Y(_029_),
    .VSS(VGND),
    .A1(net80),
    .A2(_019_));
 sg13g2_nor2_1 _162_ (.A(_020_),
    .B(net81),
    .Y(_015_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _163_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_049_),
    .A2(_052_),
    .Y(_030_),
    .B1(net72));
 sg13g2_o21ai_1 _164_ (.B1(net15),
    .VDD(VPWR),
    .Y(_031_),
    .VSS(VGND),
    .A1(_036_),
    .A2(net11));
 sg13g2_nor2_1 _165_ (.A(net73),
    .B(_031_),
    .Y(_016_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _166_ (.B1(_035_),
    .VDD(VPWR),
    .Y(_032_),
    .VSS(VGND),
    .A1(_036_),
    .A2(net11));
 sg13g2_nand2b_1 _167_ (.Y(_033_),
    .B(_072_),
    .A_N(net13),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and4_1 _168_ (.A(net16),
    .B(_048_),
    .C(_032_),
    .D(_033_),
    .X(_017_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a221oi_1 _169_ (.VDD(VPWR),
    .VSS(VGND),
    .B2(_034_),
    .C1(_045_),
    .B1(_033_),
    .A1(_054_),
    .Y(_018_),
    .A2(_073_));
 sg13g2_dfrbpq_1 _170_ (.RESET_B(net46),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_000_),
    .Q(\uart.shifter[0] ),
    .CLK(clknet_2_2__leaf_clk));
 sg13g2_tiehi _170__46 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net46));
 sg13g2_dfrbpq_1 _171_ (.RESET_B(net47),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_001_),
    .Q(\uart.shifter[1] ),
    .CLK(clknet_2_2__leaf_clk));
 sg13g2_tiehi _171__47 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net47));
 sg13g2_dfrbpq_1 _172_ (.RESET_B(net45),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_002_),
    .Q(\uart.shifter[2] ),
    .CLK(clknet_2_3__leaf_clk));
 sg13g2_tiehi _172__45 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net45));
 sg13g2_dfrbpq_1 _173_ (.RESET_B(net43),
    .VSS(VGND),
    .VDD(VPWR),
    .D(net61),
    .Q(\uart.shifter[3] ),
    .CLK(clknet_2_3__leaf_clk));
 sg13g2_tiehi _173__43 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net43));
 sg13g2_dfrbpq_1 _174_ (.RESET_B(net41),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_004_),
    .Q(\uart.shifter[4] ),
    .CLK(clknet_2_2__leaf_clk));
 sg13g2_tiehi _174__41 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net41));
 sg13g2_dfrbpq_1 _175_ (.RESET_B(net39),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_005_),
    .Q(\uart.shifter[5] ),
    .CLK(clknet_2_3__leaf_clk));
 sg13g2_tiehi _175__39 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net39));
 sg13g2_dfrbpq_1 _176_ (.RESET_B(net56),
    .VSS(VGND),
    .VDD(VPWR),
    .D(net58),
    .Q(\uart.shifter[6] ),
    .CLK(clknet_2_3__leaf_clk));
 sg13g2_tiehi _176__56 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net56));
 sg13g2_dfrbpq_1 _177_ (.RESET_B(net54),
    .VSS(VGND),
    .VDD(VPWR),
    .D(net68),
    .Q(\uart.shifter[7] ),
    .CLK(clknet_2_1__leaf_clk));
 sg13g2_tiehi _177__54 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net54));
 sg13g2_dfrbpq_1 _178_ (.RESET_B(net52),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_008_),
    .Q(tx),
    .CLK(clknet_2_1__leaf_clk));
 sg13g2_tiehi _178__52 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net52));
 sg13g2_dfrbpq_1 _179_ (.RESET_B(net51),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_009_),
    .Q(\uart.stop_done ),
    .CLK(clknet_2_1__leaf_clk));
 sg13g2_tiehi _179__51 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net51));
 sg13g2_dfrbpq_1 _180_ (.RESET_B(net50),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_010_),
    .Q(\uart.state[0] ),
    .CLK(clknet_2_1__leaf_clk));
 sg13g2_tiehi _180__50 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net50));
 sg13g2_dfrbpq_1 _181_ (.RESET_B(net48),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_011_),
    .Q(\uart.state[1] ),
    .CLK(clknet_2_1__leaf_clk));
 sg13g2_tiehi _181__48 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net48));
 sg13g2_dfrbpq_1 _182_ (.RESET_B(net44),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_012_),
    .Q(\uart.timer[0] ),
    .CLK(clknet_2_0__leaf_clk));
 sg13g2_tiehi _182__44 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net44));
 sg13g2_dfrbpq_1 _183_ (.RESET_B(net40),
    .VSS(VGND),
    .VDD(VPWR),
    .D(net71),
    .Q(\uart.timer[1] ),
    .CLK(clknet_2_0__leaf_clk));
 sg13g2_tiehi _183__40 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net40));
 sg13g2_dfrbpq_1 _184_ (.RESET_B(net55),
    .VSS(VGND),
    .VDD(VPWR),
    .D(net79),
    .Q(\uart.timer[2] ),
    .CLK(clknet_2_0__leaf_clk));
 sg13g2_tiehi _184__55 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net55));
 sg13g2_dfrbpq_1 _185_ (.RESET_B(net49),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_015_),
    .Q(\uart.timer[3] ),
    .CLK(clknet_2_0__leaf_clk));
 sg13g2_tiehi _185__49 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net49));
 sg13g2_dfrbpq_1 _186_ (.RESET_B(net42),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_016_),
    .Q(\uart.bit_idx[0] ),
    .CLK(clknet_2_0__leaf_clk));
 sg13g2_tiehi _186__42 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net42));
 sg13g2_dfrbpq_1 _187_ (.RESET_B(net53),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_017_),
    .Q(\uart.bit_idx[1] ),
    .CLK(clknet_2_2__leaf_clk));
 sg13g2_tiehi _187__53 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net53));
 sg13g2_dfrbpq_1 _188_ (.RESET_B(net38),
    .VSS(VGND),
    .VDD(VPWR),
    .D(net76),
    .Q(\uart.bit_idx[2] ),
    .CLK(clknet_2_2__leaf_clk));
 sg13g2_tiehi _188__38 (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(net38));
 sg13g2_buf_1 _230_ (.A(tx),
    .X(uo_out[0]),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 _231_ (.A(busy),
    .X(uo_out[1]),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_16 clkbuf_0_clk (.X(clknet_0_clk),
    .A(clk),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_16 clkbuf_2_0__f_clk (.X(clknet_2_0__leaf_clk),
    .A(clknet_0_clk),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_16 clkbuf_2_1__f_clk (.X(clknet_2_1__leaf_clk),
    .A(clknet_0_clk),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_16 clkbuf_2_2__f_clk (.X(clknet_2_2__leaf_clk),
    .A(clknet_0_clk),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_16 clkbuf_2_3__f_clk (.X(clknet_2_3__leaf_clk),
    .A(clknet_0_clk),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_inv_1 clkload0 (.VDD(VPWR),
    .A(clknet_2_3__leaf_clk),
    .VSS(VGND));
 sg13g2_buf_1 fanout11 (.A(net13),
    .X(net11),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 fanout12 (.A(net13),
    .X(net12),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 fanout13 (.A(_053_),
    .X(net13),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 fanout14 (.A(net65),
    .X(net14),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 fanout15 (.A(net1),
    .X(net15),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 fanout16 (.A(net1),
    .X(net16),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_dlygate4sd3_1 hold57 (.A(\uart.shifter[6] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net57));
 sg13g2_dlygate4sd3_1 hold58 (.A(_006_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net58));
 sg13g2_dlygate4sd3_1 hold59 (.A(\uart.shifter[5] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net59));
 sg13g2_dlygate4sd3_1 hold60 (.A(\uart.shifter[3] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net60));
 sg13g2_dlygate4sd3_1 hold61 (.A(_003_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net61));
 sg13g2_dlygate4sd3_1 hold62 (.A(\uart.shifter[2] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net62));
 sg13g2_dlygate4sd3_1 hold63 (.A(\uart.shifter[1] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net63));
 sg13g2_dlygate4sd3_1 hold64 (.A(\uart.shifter[4] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net64));
 sg13g2_dlygate4sd3_1 hold65 (.A(\uart.state[0] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net65));
 sg13g2_dlygate4sd3_1 hold66 (.A(_022_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net66));
 sg13g2_dlygate4sd3_1 hold67 (.A(\uart.shifter[7] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net67));
 sg13g2_dlygate4sd3_1 hold68 (.A(_007_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net68));
 sg13g2_dlygate4sd3_1 hold69 (.A(\uart.timer[1] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net69));
 sg13g2_dlygate4sd3_1 hold70 (.A(_027_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net70));
 sg13g2_dlygate4sd3_1 hold71 (.A(_013_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net71));
 sg13g2_dlygate4sd3_1 hold72 (.A(\uart.bit_idx[0] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net72));
 sg13g2_dlygate4sd3_1 hold73 (.A(_030_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net73));
 sg13g2_dlygate4sd3_1 hold74 (.A(\uart.shifter[0] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net74));
 sg13g2_dlygate4sd3_1 hold75 (.A(\uart.bit_idx[2] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net75));
 sg13g2_dlygate4sd3_1 hold76 (.A(_018_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net76));
 sg13g2_dlygate4sd3_1 hold77 (.A(\uart.timer[2] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net77));
 sg13g2_dlygate4sd3_1 hold78 (.A(_028_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net78));
 sg13g2_dlygate4sd3_1 hold79 (.A(_014_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net79));
 sg13g2_dlygate4sd3_1 hold80 (.A(\uart.timer[3] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net80));
 sg13g2_dlygate4sd3_1 hold81 (.A(_029_),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net81));
 sg13g2_dlygate4sd3_1 hold82 (.A(\uart.state[1] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net82));
 sg13g2_dlygate4sd3_1 hold83 (.A(\uart.timer[0] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net83));
 sg13g2_dlygate4sd3_1 hold84 (.A(\uart.bit_idx[1] ),
    .VDD(VPWR),
    .VSS(VGND),
    .X(net84));
 sg13g2_buf_1 input1 (.A(rst_n),
    .X(net1),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input10 (.A(uio_in[0]),
    .X(net10),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input2 (.A(ui_in[0]),
    .X(net2),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input3 (.A(ui_in[1]),
    .X(net3),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input4 (.A(ui_in[2]),
    .X(net4),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input5 (.A(ui_in[3]),
    .X(net5),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input6 (.A(ui_in[4]),
    .X(net6),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input7 (.A(ui_in[5]),
    .X(net7),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input8 (.A(ui_in[6]),
    .X(net8),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 input9 (.A(ui_in[7]),
    .X(net9),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_17 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net17));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_18 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net18));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_19 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net19));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_20 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net20));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_21 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net21));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_22 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net22));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_23 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net23));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_24 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net24));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_25 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net25));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_26 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net26));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_27 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net27));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_28 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net28));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_29 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net29));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_30 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net30));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_31 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net31));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_32 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net32));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_33 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net33));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_34 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net34));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_35 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net35));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_36 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net36));
 sg13g2_tielo tt_um_RaghuvPotdar_Leonidas_37 (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(net37));
 assign uio_oe[0] = net;
 assign uio_oe[1] = net17;
 assign uio_oe[2] = net18;
 assign uio_oe[3] = net19;
 assign uio_oe[4] = net20;
 assign uio_oe[5] = net21;
 assign uio_oe[6] = net22;
 assign uio_oe[7] = net23;
 assign uio_out[0] = net24;
 assign uio_out[1] = net25;
 assign uio_out[2] = net26;
 assign uio_out[3] = net27;
 assign uio_out[4] = net28;
 assign uio_out[5] = net29;
 assign uio_out[6] = net30;
 assign uio_out[7] = net31;
 assign uo_out[2] = net32;
 assign uo_out[3] = net33;
 assign uo_out[4] = net34;
 assign uo_out[5] = net35;
 assign uo_out[6] = net36;
 assign uo_out[7] = net37;
endmodule
