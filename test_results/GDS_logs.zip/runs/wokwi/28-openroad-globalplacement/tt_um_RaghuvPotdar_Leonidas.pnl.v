module tt_um_RaghuvPotdar_Leonidas (clk,
    ena,
    rst_n,
    VPWR,
    VGND,
    ui_in,
    uio_in,
    uio_oe,
    uio_out,
    uo_out);
 input clk;
 input ena;
 input rst_n;
 inout VPWR;
 inout VGND;
 input [7:0] ui_in;
 input [7:0] uio_in;
 output [7:0] uio_oe;
 output [7:0] uio_out;
 output [7:0] uo_out;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire busy;
 wire tx;
 wire \uart.bit_idx[0] ;
 wire \uart.bit_idx[1] ;
 wire \uart.bit_idx[2] ;
 wire \uart.shifter[0] ;
 wire \uart.shifter[1] ;
 wire \uart.shifter[2] ;
 wire \uart.shifter[3] ;
 wire \uart.shifter[4] ;
 wire \uart.shifter[5] ;
 wire \uart.shifter[6] ;
 wire \uart.shifter[7] ;
 wire \uart.state[0] ;
 wire \uart.state[1] ;
 wire \uart.stop_done ;
 wire \uart.timer[0] ;
 wire \uart.timer[1] ;
 wire \uart.timer[2] ;
 wire \uart.timer[3] ;

 sg13g2_inv_1 _094_ (.VDD(VPWR),
    .Y(_034_),
    .A(\uart.bit_idx[2] ),
    .VSS(VGND));
 sg13g2_inv_1 _095_ (.VDD(VPWR),
    .Y(_035_),
    .A(\uart.bit_idx[1] ),
    .VSS(VGND));
 sg13g2_inv_1 _096_ (.VDD(VPWR),
    .Y(_036_),
    .A(\uart.bit_idx[0] ),
    .VSS(VGND));
 sg13g2_inv_1 _097_ (.VDD(VPWR),
    .Y(_037_),
    .A(\uart.timer[2] ),
    .VSS(VGND));
 sg13g2_inv_1 _098_ (.VDD(VPWR),
    .Y(_038_),
    .A(\uart.shifter[6] ),
    .VSS(VGND));
 sg13g2_inv_1 _099_ (.VDD(VPWR),
    .Y(_039_),
    .A(\uart.shifter[5] ),
    .VSS(VGND));
 sg13g2_inv_1 _100_ (.VDD(VPWR),
    .Y(_040_),
    .A(\uart.shifter[4] ),
    .VSS(VGND));
 sg13g2_inv_1 _101_ (.VDD(VPWR),
    .Y(_041_),
    .A(\uart.shifter[3] ),
    .VSS(VGND));
 sg13g2_inv_1 _102_ (.VDD(VPWR),
    .Y(_042_),
    .A(\uart.shifter[2] ),
    .VSS(VGND));
 sg13g2_inv_1 _103_ (.VDD(VPWR),
    .Y(_043_),
    .A(\uart.shifter[1] ),
    .VSS(VGND));
 sg13g2_inv_1 _104_ (.VDD(VPWR),
    .Y(_044_),
    .A(\uart.shifter[0] ),
    .VSS(VGND));
 sg13g2_inv_1 _105_ (.VDD(VPWR),
    .Y(_045_),
    .A(rst_n),
    .VSS(VGND));
 sg13g2_nor2_1 _106_ (.A(\uart.state[1] ),
    .B(\uart.state[0] ),
    .Y(_046_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_or2_1 _107_ (.VSS(VGND),
    .VDD(VPWR),
    .X(_047_),
    .B(\uart.state[0] ),
    .A(\uart.state[1] ));
 sg13g2_nand2b_1 _108_ (.Y(busy),
    .B(_046_),
    .A_N(\uart.stop_done ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand2_1 _109_ (.Y(_048_),
    .A(uio_in[0]),
    .B(_046_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor2b_1 _110_ (.A(\uart.state[0] ),
    .B_N(\uart.state[1] ),
    .Y(_049_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand2b_1 _111_ (.Y(_050_),
    .B(\uart.state[1] ),
    .A_N(\uart.state[0] ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand2_1 _112_ (.Y(_051_),
    .A(\uart.timer[1] ),
    .B(\uart.timer[0] ),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and4_1 _113_ (.A(\uart.timer[3] ),
    .B(\uart.timer[2] ),
    .C(\uart.timer[1] ),
    .D(\uart.timer[0] ),
    .X(_052_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a22oi_1 _114_ (.Y(_053_),
    .B1(_049_),
    .B2(_052_),
    .A2(_046_),
    .A1(uio_in[0]),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_inv_1 _115_ (.VDD(VPWR),
    .Y(_054_),
    .A(_053_),
    .VSS(VGND));
 sg13g2_mux2_1 _116_ (.A0(\uart.shifter[1] ),
    .A1(ui_in[0]),
    .S(_050_),
    .X(_055_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _117_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_056_),
    .VSS(VGND),
    .A1(_053_),
    .A2(_055_));
 sg13g2_a21oi_1 _118_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_044_),
    .A2(_053_),
    .Y(_000_),
    .B1(_056_));
 sg13g2_mux2_1 _119_ (.A0(\uart.shifter[2] ),
    .A1(ui_in[1]),
    .S(_050_),
    .X(_057_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _120_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_058_),
    .VSS(VGND),
    .A1(_053_),
    .A2(_057_));
 sg13g2_a21oi_1 _121_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_043_),
    .A2(_053_),
    .Y(_001_),
    .B1(_058_));
 sg13g2_mux2_1 _122_ (.A0(\uart.shifter[3] ),
    .A1(ui_in[2]),
    .S(_050_),
    .X(_059_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _123_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_060_),
    .VSS(VGND),
    .A1(_053_),
    .A2(_059_));
 sg13g2_a21oi_1 _124_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_042_),
    .A2(_053_),
    .Y(_002_),
    .B1(_060_));
 sg13g2_mux2_1 _125_ (.A0(\uart.shifter[4] ),
    .A1(ui_in[3]),
    .S(_050_),
    .X(_061_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _126_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_062_),
    .VSS(VGND),
    .A1(_053_),
    .A2(_061_));
 sg13g2_a21oi_1 _127_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_041_),
    .A2(_053_),
    .Y(_003_),
    .B1(_062_));
 sg13g2_mux2_1 _128_ (.A0(\uart.shifter[5] ),
    .A1(ui_in[4]),
    .S(_050_),
    .X(_063_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _129_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_064_),
    .VSS(VGND),
    .A1(_053_),
    .A2(_063_));
 sg13g2_a21oi_1 _130_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_040_),
    .A2(_053_),
    .Y(_004_),
    .B1(_064_));
 sg13g2_mux2_1 _131_ (.A0(\uart.shifter[6] ),
    .A1(ui_in[5]),
    .S(_050_),
    .X(_065_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _132_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_066_),
    .VSS(VGND),
    .A1(_053_),
    .A2(_065_));
 sg13g2_a21oi_1 _133_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_039_),
    .A2(_053_),
    .Y(_005_),
    .B1(_066_));
 sg13g2_mux2_1 _134_ (.A0(\uart.shifter[7] ),
    .A1(ui_in[6]),
    .S(_050_),
    .X(_067_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _135_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_068_),
    .VSS(VGND),
    .A1(_053_),
    .A2(_067_));
 sg13g2_a21oi_1 _136_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_038_),
    .A2(_053_),
    .Y(_006_),
    .B1(_068_));
 sg13g2_nand2_1 _137_ (.Y(_069_),
    .A(\uart.shifter[7] ),
    .B(_053_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand3_1 _138_ (.B(ui_in[7]),
    .C(_046_),
    .A(uio_in[0]),
    .Y(_070_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _139_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_069_),
    .A2(_070_),
    .Y(_007_),
    .B1(_045_));
 sg13g2_o21ai_1 _140_ (.B1(\uart.state[1] ),
    .VDD(VPWR),
    .Y(_071_),
    .VSS(VGND),
    .A1(\uart.state[0] ),
    .A2(\uart.shifter[0] ));
 sg13g2_nand3_1 _141_ (.B(_047_),
    .C(_071_),
    .A(rst_n),
    .Y(_008_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and2_1 _142_ (.A(\uart.bit_idx[1] ),
    .B(\uart.bit_idx[0] ),
    .X(_072_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21o_1 _143_ (.A2(_072_),
    .A1(\uart.bit_idx[2] ),
    .B1(_050_),
    .X(_073_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor2_1 _144_ (.A(_046_),
    .B(_051_),
    .Y(_074_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor3_1 _145_ (.A(_037_),
    .B(_046_),
    .C(_051_),
    .Y(_019_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_mux2_1 _146_ (.A0(uio_in[0]),
    .A1(_052_),
    .S(_047_),
    .X(_020_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and3_1 _147_ (.X(_021_),
    .A(\uart.state[1] ),
    .B(\uart.state[0] ),
    .C(_020_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and2_1 _148_ (.A(rst_n),
    .B(_021_),
    .X(_009_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _149_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_073_),
    .A2(_020_),
    .Y(_022_),
    .B1(\uart.state[0] ));
 sg13g2_a21oi_1 _150_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(\uart.state[0] ),
    .A2(_020_),
    .Y(_023_),
    .B1(_045_));
 sg13g2_nor2b_1 _151_ (.A(_022_),
    .B_N(_023_),
    .Y(_010_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _152_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(\uart.state[0] ),
    .A2(_020_),
    .Y(_024_),
    .B1(\uart.state[1] ));
 sg13g2_nor3_1 _153_ (.A(_045_),
    .B(_021_),
    .C(_024_),
    .Y(_011_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nand2_1 _154_ (.Y(_025_),
    .A(rst_n),
    .B(_048_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_xnor2_1 _155_ (.Y(_026_),
    .A(\uart.timer[0] ),
    .B(_047_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor2_1 _156_ (.A(_025_),
    .B(_026_),
    .Y(_012_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _157_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(\uart.timer[0] ),
    .A2(_047_),
    .Y(_027_),
    .B1(\uart.timer[1] ));
 sg13g2_nor3_1 _158_ (.A(_074_),
    .B(_025_),
    .C(_027_),
    .Y(_013_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor2_1 _159_ (.A(\uart.timer[2] ),
    .B(_074_),
    .Y(_028_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_nor3_1 _160_ (.A(_019_),
    .B(_025_),
    .C(_028_),
    .Y(_014_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _161_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_029_),
    .VSS(VGND),
    .A1(\uart.timer[3] ),
    .A2(_019_));
 sg13g2_nor2_1 _162_ (.A(_020_),
    .B(_029_),
    .Y(_015_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a21oi_1 _163_ (.VSS(VGND),
    .VDD(VPWR),
    .A1(_049_),
    .A2(_052_),
    .Y(_030_),
    .B1(\uart.bit_idx[0] ));
 sg13g2_o21ai_1 _164_ (.B1(rst_n),
    .VDD(VPWR),
    .Y(_031_),
    .VSS(VGND),
    .A1(_036_),
    .A2(_053_));
 sg13g2_nor2_1 _165_ (.A(_030_),
    .B(_031_),
    .Y(_016_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_o21ai_1 _166_ (.B1(_035_),
    .VDD(VPWR),
    .Y(_032_),
    .VSS(VGND),
    .A1(_036_),
    .A2(_053_));
 sg13g2_nand2b_1 _167_ (.Y(_033_),
    .B(_072_),
    .A_N(_053_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_and4_1 _168_ (.A(rst_n),
    .B(_048_),
    .C(_032_),
    .D(_033_),
    .X(_017_),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_a221oi_1 _169_ (.VDD(VPWR),
    .VSS(VGND),
    .B2(_034_),
    .C1(_045_),
    .B1(_033_),
    .A1(_054_),
    .Y(_018_),
    .A2(_073_));
 sg13g2_dfrbpq_1 _170_ (.RESET_B(_083_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_000_),
    .Q(\uart.shifter[0] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _171_ (.RESET_B(_084_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_001_),
    .Q(\uart.shifter[1] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _172_ (.RESET_B(_082_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_002_),
    .Q(\uart.shifter[2] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _173_ (.RESET_B(_080_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_003_),
    .Q(\uart.shifter[3] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _174_ (.RESET_B(_078_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_004_),
    .Q(\uart.shifter[4] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _175_ (.RESET_B(_076_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_005_),
    .Q(\uart.shifter[5] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _176_ (.RESET_B(_093_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_006_),
    .Q(\uart.shifter[6] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _177_ (.RESET_B(_091_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_007_),
    .Q(\uart.shifter[7] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _178_ (.RESET_B(_089_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_008_),
    .Q(tx),
    .CLK(clk));
 sg13g2_dfrbpq_1 _179_ (.RESET_B(_088_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_009_),
    .Q(\uart.stop_done ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _180_ (.RESET_B(_087_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_010_),
    .Q(\uart.state[0] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _181_ (.RESET_B(_085_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_011_),
    .Q(\uart.state[1] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _182_ (.RESET_B(_081_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_012_),
    .Q(\uart.timer[0] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _183_ (.RESET_B(_077_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_013_),
    .Q(\uart.timer[1] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _184_ (.RESET_B(_092_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_014_),
    .Q(\uart.timer[2] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _185_ (.RESET_B(_086_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_015_),
    .Q(\uart.timer[3] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _186_ (.RESET_B(_079_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_016_),
    .Q(\uart.bit_idx[0] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _187_ (.RESET_B(_090_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_017_),
    .Q(\uart.bit_idx[1] ),
    .CLK(clk));
 sg13g2_dfrbpq_1 _188_ (.RESET_B(_075_),
    .VSS(VGND),
    .VDD(VPWR),
    .D(_018_),
    .Q(\uart.bit_idx[2] ),
    .CLK(clk));
 sg13g2_tiehi _189_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_075_));
 sg13g2_tiehi _190_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_076_));
 sg13g2_tiehi _191_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_077_));
 sg13g2_tiehi _192_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_078_));
 sg13g2_tiehi _193_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_079_));
 sg13g2_tiehi _194_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_080_));
 sg13g2_tiehi _195_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_081_));
 sg13g2_tiehi _196_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_082_));
 sg13g2_tiehi _197_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_083_));
 sg13g2_tiehi _198_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_084_));
 sg13g2_tiehi _199_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_085_));
 sg13g2_tiehi _200_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_086_));
 sg13g2_tiehi _201_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_087_));
 sg13g2_tiehi _202_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_088_));
 sg13g2_tiehi _203_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_089_));
 sg13g2_tiehi _204_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_090_));
 sg13g2_tiehi _205_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_091_));
 sg13g2_tiehi _206_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_092_));
 sg13g2_tiehi _207_ (.VDD(VPWR),
    .VSS(VGND),
    .L_HI(_093_));
 sg13g2_tielo _208_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_oe[0]));
 sg13g2_tielo _209_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_oe[1]));
 sg13g2_tielo _210_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_oe[2]));
 sg13g2_tielo _211_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_oe[3]));
 sg13g2_tielo _212_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_oe[4]));
 sg13g2_tielo _213_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_oe[5]));
 sg13g2_tielo _214_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_oe[6]));
 sg13g2_tielo _215_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_oe[7]));
 sg13g2_tielo _216_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_out[0]));
 sg13g2_tielo _217_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_out[1]));
 sg13g2_tielo _218_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_out[2]));
 sg13g2_tielo _219_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_out[3]));
 sg13g2_tielo _220_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_out[4]));
 sg13g2_tielo _221_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_out[5]));
 sg13g2_tielo _222_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_out[6]));
 sg13g2_tielo _223_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uio_out[7]));
 sg13g2_tielo _224_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uo_out[2]));
 sg13g2_tielo _225_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uo_out[3]));
 sg13g2_tielo _226_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uo_out[4]));
 sg13g2_tielo _227_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uo_out[5]));
 sg13g2_tielo _228_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uo_out[6]));
 sg13g2_tielo _229_ (.VDD(VPWR),
    .VSS(VGND),
    .L_LO(uo_out[7]));
 sg13g2_buf_1 _230_ (.A(tx),
    .X(uo_out[0]),
    .VDD(VPWR),
    .VSS(VGND));
 sg13g2_buf_1 _231_ (.A(busy),
    .X(uo_out[1]),
    .VDD(VPWR),
    .VSS(VGND));
endmodule
